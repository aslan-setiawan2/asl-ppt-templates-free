﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.OleDb

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CmbStn.Items.Add("PC")
        CmbStn.Items.Add("Karton")
        CmbStn.Items.Add("Bungkus")
        CmbStn.Items.Add("KG")
        TampilGrid()

    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        Dim cnnOLEDB As New OleDbConnection
        Dim cmdOLEDB As New OleDbCommand
        Dim cmdInsert As New OleDbCommand
        Dim sqlAdapter As New OleDbDataAdapter

        Dim strConnectionString = "Provider=SQLOLEDB; Persist Security Info=False; Integrated Security=SSPI; database=DB_BARANGINPUT; Data Source = ASL"

        cnnOLEDB.ConnectionString = strConnectionString
        cnnOLEDB.Open()
        cmdInsert.CommandText = "INSERT INTO masterbarang (kodebarang, namabarang, satuan, tanggal) VALUES ('" & KdBrg.Text & "', '" & KdNm.Text & "', '" & CmbStn.Text & "', '" & Format(DateTgl.Value, "dd/MMM/yyyy") & "')"
        cmdInsert.CommandType = CommandType.Text
        cmdInsert.Connection = cnnOLEDB
        cmdInsert.ExecuteNonQuery()
        MsgBox("Data Berhasil Disimpan !")

        TampilGrid()
        Clear()

    End Sub

    Private Sub TampilGrid()
        Dim Conn As SqlConnection
        Dim strSQL As String
        Dim m_DataSet As DataSet

        Dim ConnectionString = "Persist Security Info= False; Integrated Security = SSPI; database=DB_BARANGINPUT; Data Source = ASL"
        strSQL = "select * from masterbarang"
        Conn = New SqlConnection(ConnectionString)
        Dim data_Adapter = New SqlDataAdapter(strSQL, Conn)
        data_Adapter.TableMappings.Add("Table", "masterbarang")
        m_DataSet = New DataSet()
        data_Adapter.Fill(m_DataSet)
        DataGridView1.DataSource = m_DataSet
        DataGridView1.DataMember = "masterbarang"

    End Sub

    Private Sub Clear()
        KdBrg.Text = ""
        KdNm.Text = ""
        CmbStn.Text = ""
        DateTgl.Text = ""
    End Sub




    Private Sub btnedit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnedit.Click
        Dim cnnOLEDB As New OleDbConnection
        Dim cmdOLEDB As New OleDbCommand
        Dim cmdUpdate As New OleDbCommand
        Dim sqlAdapter As New OleDbDataAdapter

        Dim strConnectionString = "Provider=SQLOLEDB; Persist Security Info=False; Integrated Security=SSPI; database=DB_BARANGINPUT; Data Source = ASL"

        cnnOLEDB.ConnectionString = strConnectionString
        cnnOLEDB.Open()

        cmdUpdate.CommandText = "UPDATE masterbarang SET  namabarang='" & KdNm.Text & "', satuan='" & CmbStn.Text & "', tanggal='" & Format(DateTgl.Value, "dd/MMM/yyyy") & "' WHERE  kodebarang = " & KdBrg.Text & ""

        cmdUpdate.CommandType = CommandType.Text
        cmdUpdate.Connection = cnnOLEDB
        cmdUpdate.ExecuteNonQuery()
        MsgBox("Data Berhasil Diedit !")

        TampilGrid()
        Clear()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim cnnOLEDB As New OleDbConnection
        Dim cmdOLEDB As New OleDbCommand
        Dim cmdDelete As New OleDbCommand
        Dim sqlAdapter As New OleDbDataAdapter

        Dim strConnectionString = "Provider=SQLOLEDB; Persist Security Info=False; Integrated Security=SSPI; database=DB_BARANGINPUT; Data Source = ASL"

        cnnOLEDB.ConnectionString = strConnectionString
        cnnOLEDB.Open()

        cmdDelete.CommandText = "DELETE masterbarang WHERE  kodebarang = " & KdBrg.Text & ""

        cmdDelete.CommandType = CommandType.Text
        cmdDelete.Connection = cnnOLEDB
        cmdDelete.ExecuteNonQuery()
        MsgBox("Data Berhasil Dihapus !")

        TampilGrid()
        Clear()

    End Sub

    Private Sub Panel2_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel2.Paint

    End Sub
End Class
